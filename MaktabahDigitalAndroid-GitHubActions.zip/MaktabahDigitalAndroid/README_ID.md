# Maktabah Digital — Build APK dari HP

Proyek ini membungkus `index.html` Maktabah Digital ke dalam aplikasi Android WebView.

## Cara build APK hanya dari HP dengan GitHub

1. Buka GitHub di browser HP dan login.
2. Buat repository baru, misalnya `MaktabahDigitalAndroid`.
3. Upload **semua isi folder ZIP ini** ke repository tersebut. Pastikan folder `.github/workflows/build-apk.yml` ikut ter-upload.
4. Masuk ke tab **Actions** pada repository.
5. Pilih workflow **Build Maktabah Digital APK**.
6. Tekan **Run workflow** jika workflow belum otomatis berjalan.
7. Tunggu sampai proses selesai dengan tanda centang hijau.
8. Buka hasil workflow tersebut, lalu cari bagian **Artifacts**.
9. Download **Maktabah-Digital-debug-apk** dan ekstrak ZIP-nya.
10. Instal `app-debug.apk` di HP.

### Jika menu Actions tidak muncul
- Pastikan repository tidak memblokir Actions.
- Pastikan file berada tepat di `.github/workflows/build-apk.yml`.
- Push/upload perubahan ke branch `main`.

### Catatan
- APK yang dihasilkan adalah **debug APK** dan dapat dipasang untuk penggunaan pribadi/pengujian.
- Untuk publikasi Play Store, diperlukan proses signing/release tersendiri.
- Aplikasi memerlukan internet karena halaman menggunakan Google Fonts dan beberapa tautan/gambar eksternal.
- Link HTTPS dari kitab/media sosial dibuka melalui browser atau aplikasi yang sesuai.
